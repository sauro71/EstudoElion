#include "stdafx.h"

#if DIRECTX_BACKEND_ENABLE == 1
namespace EDirectX
{
	mu_uint32 CurrentCommandBufferIndex = 0;
};
#endif