#ifndef __MU_AUDIO_BACKEND_H__
#define __MU_AUDIO_BACKEND_H__

#pragma once

namespace EAudioBackend
{
	const mu_boolean Initialize();
	void Destroy();

	void 
};

#endif