#ifndef __MU_DIRECTX_DEBUG_H__
#define __MU_DIRECTX_DEBUG_H__

#pragma once

namespace EDirectXDebug
{
};

#endif