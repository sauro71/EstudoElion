#include "stdafx.h"
#include "mu_standard_types.h"

#if __ANDROID__
mu_asciistr MUBasePrefPath;
mu_string MUBasePrefPathUnicode;
#endif