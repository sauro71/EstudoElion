#include "stdafx.h"
#include "mu_buffstatesystem.h"

BuffStateSystem g_BuffSystem;

BuffStateSystem::BuffStateSystem()
{

}

BuffStateSystem::~BuffStateSystem()
{

}