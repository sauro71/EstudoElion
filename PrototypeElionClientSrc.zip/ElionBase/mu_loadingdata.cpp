#include "stdafx.h"
#include "mu_loadingdata.h"

namespace LoadingData
{
	mu_atomic_uint32_t Counter[LOADING_COUNTER::MAX];
};